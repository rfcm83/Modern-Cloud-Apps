﻿using AutoMapper;
using Contoso.Apps.SportsLeague.Data.Models;
using System.Collections.Generic;

namespace Contoso.Apps.SportsLeague.Offers
{
    public class AutoMapping : Profile
    {
        public AutoMapping()
        {
        }
    }

}
